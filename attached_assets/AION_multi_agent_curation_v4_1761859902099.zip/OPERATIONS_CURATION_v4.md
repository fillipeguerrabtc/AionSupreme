# Operação — Curadoria HITL

1) **Adicionar conteúdo**: upload/Promover → `/api/curation/add` (ou `/api/kb/promote` se você já usa). 
2) **Revisar**: UI Admin → Curadoria → editar título/tags/namespaces.
3) **Aprovar e publicar**: envia `/api/curation/approve` → persiste no KB → emite `DOC_UPDATED` + `AGENT_NAMESPACES_CHANGED` → Indexador reconstroi.
4) **Rejeitar**: `/api/curation/reject` → não publica, remove pendência.
5) **Auditar**: registre no seu logger/auditoria (quem, quando, o quê).

**Observação**: Todos os endpoints exigem `x-tenant-id` e autenticação/autorização Admin.
