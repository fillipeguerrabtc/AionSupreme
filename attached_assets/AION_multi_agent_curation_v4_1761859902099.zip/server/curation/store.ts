// server/curation/store.ts
// Placeholder store to integrate with your real KB/Docs persistence.
// Replace the in-memory parts with DB calls (Postgres, Firestore, etc.).

export type PendingDoc = {
  docId: string;
  tenantId: string;
  title?: string;
  text: string;
  tags?: string[];
  suggestedNamespaces: string[];
  createdAt: number;
  createdBy?: string; // agent/user
  notes?: string;
};

const mem: Record<string, PendingDoc> = {};

export async function addPendingDoc(doc: PendingDoc) {
  mem[doc.docId] = doc;
  return doc;
}

export async function listPending(tenantId: string): Promise<PendingDoc[]> {
  return Object.values(mem).filter(d => d.tenantId === tenantId);
}

export async function getPending(tenantId: string, docId: string): Promise<PendingDoc | null> {
  const d = mem[docId];
  if (!d || d.tenantId !== tenantId) return null;
  return d;
}

export async function editPending(tenantId: string, docId: string, patch: Partial<PendingDoc>) {
  const d = await getPending(tenantId, docId);
  if (!d) return null;
  mem[docId] = { ...d, ...patch };
  return mem[docId];
}

export async function removePending(tenantId: string, docId: string) {
  const d = await getPending(tenantId, docId);
  if (!d) return false;
  delete mem[docId];
  return true;
}

// Publication stub: plug into your KB store, versioning and indexing
export async function publishToKB(tenantId: string, payload: { docId: string, title?: string, text: string, tags?: string[], namespaces: string[] }) {
  // TODO: persist document in your KB; return published id
  const publishedId = payload.docId; // reuse for now
  return { publishedId };
}
