// server/routes/curation.ts
import type { Express, Request, Response } from "express";
import { publishEvent } from "../events";
import { addPendingDoc, listPending, getPending, editPending, removePending, publishToKB } from "../curation/store";

// GET /api/curation/pending
export function registerCurationRoutes(app: Express) {
  app.get("/api/curation/pending", async (req: Request, res: Response) => {
    const tenantId = (req.headers["x-tenant-id"] as string) || "";
    const items = await listPending(tenantId);
    res.json(items);
  });

  // PATCH /api/curation/edit
  app.patch("/api/curation/edit", async (req: Request, res: Response) => {
    const tenantId = (req.headers["x-tenant-id"] as string) || "";
    const { docId, patch } = req.body || {};
    const item = await editPending(tenantId, docId, patch || {});
    if (!item) return res.status(404).json({ error: "not_found" });
    res.json(item);
  });

  // POST /api/curation/approve
  app.post("/api/curation/approve", async (req: Request, res: Response) => {
    const tenantId = (req.headers["x-tenant-id"] as string) || "";
    const { docId, namespaces, tags, note, title } = req.body || {};
    const item = await getPending(tenantId, docId);
    if (!item) return res.status(404).json({ error: "not_found" });

    const pub = await publishToKB(tenantId, { docId, title: title || item.title, text: item.text, tags: tags || item.tags, namespaces });
    await publishEvent("DOC_UPDATED", { tenantId, docId: pub.publishedId, namespaces });
    await publishEvent("AGENT_NAMESPACES_CHANGED", { tenantId, namespaces });

    await removePending(tenantId, docId);
    res.json({ ok: true, publishedId: pub.publishedId, namespaces });
  });

  // POST /api/curation/reject
  app.post("/api/curation/reject", async (req: Request, res: Response) => {
    const tenantId = (req.headers["x-tenant-id"] as string) || "";
    const { docId, reason } = req.body || {};
    const ok = await removePending(tenantId, docId);
    if (!ok) return res.status(404).json({ error: "not_found" });
    await publishEvent("DOC_DELETED", { tenantId, docId, reason });
    res.json({ ok: true });
  });

  // Utility endpoint: add pending (for Curator/Promote flow)
  app.post("/api/curation/add", async (req: Request, res: Response) => {
    const tenantId = (req.headers["x-tenant-id"] as string) || "";
    const { text, title, suggestedNamespaces, tags, createdBy } = req.body || {};
    const docId = Math.random().toString(36).slice(2);
    const item = await addPendingDoc({
      docId, tenantId, text, title, tags, suggestedNamespaces: suggestedNamespaces || ["curation/pending"], createdAt: Date.now(), createdBy
    });
    res.status(201).json(item);
  });
}
