// server/agent/curator_executive.ts
import type { Agent, AgentInput, AgentOutput, AgentRunContext } from "./types";

export const CuratorExecutiveAgent: Agent = {
  id: "curator-executive-agent",
  name: "Curador Executivo (Humano+IA)",
  type: "specialist",
  async run(input: AgentInput, ctx: AgentRunContext): Promise<AgentOutput> {
    // This agent does not publish directly.
    // It prepares a pending item and requires human approval in Admin UI.
    const suggestedNamespaces = ["curation/pending"];
    const text = input.query || "";
    return {
      text: `Conteúdo enviado à fila de curadoria. Namespaces sugeridos: ${suggestedNamespaces.join(", ")}`
    };
  }
};
