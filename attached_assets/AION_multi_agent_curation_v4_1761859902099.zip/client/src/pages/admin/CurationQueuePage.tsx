// client/src/pages/admin/CurationQueuePage.tsx
"use client";
import React, { useEffect, useState } from "react";
import CurationItemEditor from "../../components/curation/CurationItemEditor";

type Item = {
  docId: string;
  tenantId: string;
  title?: string;
  text: string;
  tags?: string[];
  suggestedNamespaces: string[];
  createdAt: number;
  createdBy?: string;
};

export default function CurationQueuePage() {
  const [items, setItems] = useState<Item[]>([]);
  const [selected, setSelected] = useState<Item|null>(null);

  async function load() {
    const r = await fetch("/api/curation/pending", { headers: { "x-tenant-id": "default-tenant" } });
    const j = await r.json();
    setItems(j);
  }

  useEffect(()=>{ load(); }, []);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-semibold">Curadoria — Pendências</h1>
      <table className="w-full text-sm border">
        <thead>
          <tr className="bg-gray-50">
            <th className="text-left p-2">Título</th>
            <th className="text-left p-2">Namespaces sugeridos</th>
            <th className="text-left p-2">Criado em</th>
            <th className="p-2">Ações</th>
          </tr>
        </thead>
        <tbody>
          {items.map(it => (
            <tr key={it.docId} className="border-t">
              <td className="p-2">{it.title || "(sem título)"}</td>
              <td className="p-2">{it.suggestedNamespaces.join(", ")}</td>
              <td className="p-2">{new Date(it.createdAt).toLocaleString()}</td>
              <td className="p-2">
                <button className="px-2 py-1 border mr-2" onClick={()=>setSelected(it)}>Editar/Aprovar</button>
              </td>
            </tr>
          ))}
          {items.length === 0 && (
            <tr><td className="p-4 opacity-60" colSpan={4}>Nenhum item pendente.</td></tr>
          )}
        </tbody>
      </table>

      {selected && <CurationItemEditor item={selected} onClose={()=>{ setSelected(null); load(); }} />}
    </div>
  );
}
