// client/src/components/curation/CurationItemEditor.tsx
"use client";
import React, { useState } from "react";

export default function CurationItemEditor({ item, onClose }: { item: any, onClose: ()=>void }) {
  const [title, setTitle] = useState(item.title || "");
  const [text, setText] = useState(item.text || "");
  const [namespaces, setNamespaces] = useState<string>(item.suggestedNamespaces.join(", "));
  const [tags, setTags] = useState<string>((item.tags || []).join(", "));
  const [note, setNote] = useState<string>("");
  const [busy, setBusy] = useState(false);

  async function approve() {
    setBusy(true);
    const body = {
      docId: item.docId,
      title,
      namespaces: namespaces.split(",").map((s:string)=>s.trim()).filter(Boolean),
      tags: tags.split(",").map((s:string)=>s.trim()).filter(Boolean),
      note
    };
    const r = await fetch("/api/curation/approve", {
      method: "POST",
      headers: { "Content-Type":"application/json", "x-tenant-id": "default-tenant" },
      body: JSON.stringify(body)
    });
    setBusy(false);
    if (!r.ok) return alert("Falha ao aprovar");
    onClose();
  }

  async function reject() {
    setBusy(true);
    const r = await fetch("/api/curation/reject", {
      method: "POST",
      headers: { "Content-Type":"application/json", "x-tenant-id": "default-tenant" },
      body: JSON.stringify({ docId: item.docId, reason: "Reprovado pelo revisor" })
    });
    setBusy(false);
    if (!r.ok) return alert("Falha ao rejeitar");
    onClose();
  }

  return (
    <div className="fixed inset-0 bg-black/30 flex items-center justify-center">
      <div className="bg-white w-[800px] max-h-[90vh] overflow-auto p-4 space-y-3 rounded shadow">
        <div className="text-lg font-semibold">Curadoria</div>
        <div>
          <label className="block text-xs opacity-70">Título</label>
          <input className="border p-2 w-full" value={title} onChange={e=>setTitle(e.target.value)} />
        </div>
        <div>
          <label className="block text-xs opacity-70">Texto</label>
          <textarea className="border p-2 w-full h-[200px]" value={text} onChange={e=>setText(e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs opacity-70">Namespaces (separados por vírgula)</label>
            <input className="border p-2 w-full" value={namespaces} onChange={e=>setNamespaces(e.target.value)} />
          </div>
          <div>
            <label className="block text-xs opacity-70">Tags (separadas por vírgula)</label>
            <input className="border p-2 w-full" value={tags} onChange={e=>setTags(e.target.value)} />
          </div>
        </div>
        <div>
          <label className="block text-xs opacity-70">Nota do revisor</label>
          <input className="border p-2 w-full" value={note} onChange={e=>setNote(e.target.value)} />
        </div>
        <div className="flex gap-2 justify-end pt-2">
          <button className="px-3 py-1 border" onClick={onClose}>Fechar</button>
          <button className="px-3 py-1 border" disabled={busy} onClick={reject}>Rejeitar</button>
          <button className="px-3 py-1 border" disabled={busy} onClick={approve}>Aprovar e Publicar</button>
        </div>
      </div>
    </div>
  );
}
