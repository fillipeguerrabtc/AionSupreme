# AION — Módulo de Curadoria com Aprovação Humana (v4)

Este pacote adiciona:
- Curadoria **human-in-the-loop** (HITL) obrigatória antes da publicação.
- Agentes: **Curador** e **Curador Executivo** (IA+hómuno).
- Rotas para listar pendências, **aprovar/publicar**, **rejeitar** e **editar**.
- UI Admin: **Fila de Curadoria** + **Editor/Ações**.

## Instalação Rápida
1. Copie as pastas `server/` e `client/` deste pacote para o seu monorepo.
2. Registre rotas no `server/routes.ts`:
   ```ts
   import { registerCurationRoutes } from "./routes/curation";
   // já exista: import { registerKbPromoteRoutes } from "./routes/kb_promote";
   export function registerRoutes(app) {
     // ...
     registerCurationRoutes(app);
     // registerKbPromoteRoutes(app); // se já usa o fluxo de "Promover resposta"
   }
   ```
3. Adicione a página no sidebar (link para `/admin/curation` → `CurationQueuePage.tsx`).
4. Seeds: mescle `server/seeds/curators.seed.json` ao seu seed de agentes e rode o seeder.

## Fluxo Operacional
- **Entrada**: agentes/usuários enviam conteúdo (upload ou "Promover resposta") → vai para `curation/pending`.
- **Curadoria**: revisores humanos abrem **Admin → Curadoria**, editam título/tags/namespaces.
- **Publicação**: ao aprovar, o backend persiste no KB real e emite eventos:
  - `DOC_UPDATED` (ou `DOC_INGESTED` em first-publish),
  - `AGENT_NAMESPACES_CHANGED` → indexador reconstrói os namespaces.
- **Rejeição**: remove da fila, emite `DOC_DELETED` (para auditoria).

## Integração com seu KB real
- Substitua os métodos em `server/curation/store.ts` para usar seu DB real.
- Implemente `publishToKB(...)` gravando documento versionado e retornando `publishedId`.
- O indexador existente deve expor `rebuildNamespaceIndex(tenantId, namespace)` (já previsto no upgrade).

## Segurança e ACL
- Somente perfis **Admin/Curador** devem acessar as rotas de curadoria.
- Mantenha o **Curador** com leitura global (`*`) e escrita em `curation/*`; a publicação efetiva é feita pelo backend após aprovação humana.

## Auditoria
- Registre no seu `traces` ou numa tabela `audit_logs` quem aprovou/rejeitou com `timestamp`, `docId`, `namespaces` e `note`.

## UI
- `client/src/pages/admin/CurationQueuePage.tsx` lista pendências e abre o `CurationItemEditor`.
- `client/src/components/curation/CurationItemEditor.tsx` envia `approve`/`reject`/`edit` para as rotas correspondentes.

