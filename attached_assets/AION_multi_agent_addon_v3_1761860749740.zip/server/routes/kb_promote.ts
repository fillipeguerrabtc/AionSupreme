// server/routes/kb_promote.ts
import type { Express, Request, Response } from "express";
import { publishEvent } from "../events";

async function createDocFromAnswer(tenantId: string, payload: any) {
  const docId = Math.random().toString(36).slice(2);
  const namespaces = payload.suggestedNamespaces || ["curation/pending"];
  // TODO: Persist doc in your KB store with versioning (title, text, tags)
  return { docId, namespaces };
}

export function registerKbPromoteRoutes(app: Express) {
  app.post("/api/kb/promote", async (req: Request, res: Response) => {
    try {
      const tenantId = (req.headers["x-tenant-id"] as string) || "";
      const body = req.body || {};
      const { docId, namespaces } = await createDocFromAnswer(tenantId, body);
      await publishEvent("DOC_INGESTED", { tenantId, docId, namespaces });
      res.status(201).json({ ok: true, docId, namespaces });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || "internal_error" });
    }
  });
}
