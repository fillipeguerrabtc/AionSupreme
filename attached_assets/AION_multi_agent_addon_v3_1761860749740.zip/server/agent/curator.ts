// server/agent/curator.ts
import type { Agent, AgentInput, AgentOutput, AgentRunContext } from "./types";
import { publishEvent } from "../events";

export const CuratorAgent: Agent = {
  id: "curator-agent",
  name: "Curador de Conhecimento",
  type: "specialist",
  async run(input: AgentInput, ctx: AgentRunContext): Promise<AgentOutput> {
    const text = input.query.trim();
    const suggested = ["curation/pending"];
    await publishEvent("DOC_INGESTED", { tenantId: ctx.tenantId, docId: "ad-hoc", namespaces: suggested });
    return { text: `Curadoria recebida. Sugestão de namespaces: ${suggested.join(", ")}` };
  }
};
