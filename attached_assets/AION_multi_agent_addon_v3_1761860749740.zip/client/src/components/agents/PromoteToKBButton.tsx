// client/src/components/agents/PromoteToKBButton.tsx
"use client";
import React, { useState } from "react";

type Props = { answerText: string; defaultNamespaces?: string[] };

export default function PromoteToKBButton({ answerText, defaultNamespaces = [] }: Props) {
  const [busy, setBusy] = useState(false);
  const [ok, setOk] = useState<null|{docId:string; namespaces:string[]}|false>(null);
  async function promote() {
    setBusy(true);
    try {
      const payload = {
        text: answerText,
        suggestedNamespaces: defaultNamespaces.length ? defaultNamespaces : ["curation/pending"]
      };
      const res = await fetch("/api/kb/promote", {
        method: "POST",
        headers: { "Content-Type":"application/json", "x-tenant-id": "default-tenant" },
        body: JSON.stringify(payload)
      });
      const j = await res.json();
      if (!res.ok) throw new Error(j?.error || "fail");
      setOk({ docId: j.docId, namespaces: j.namespaces });
    } catch (e) {
      setOk(false);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="inline-flex items-center gap-2">
      <button className="px-3 py-1 border text-sm" disabled={busy} onClick={promote}>
        {busy ? "Promovendo..." : "Promover resposta à KB"}
      </button>
      {ok && ok !== false && <span className="text-xs opacity-70">Promovido: {ok.docId}</span>}
      {ok === false && <span className="text-xs text-red-600">Falha ao promover</span>}
    </div>
  );
}
