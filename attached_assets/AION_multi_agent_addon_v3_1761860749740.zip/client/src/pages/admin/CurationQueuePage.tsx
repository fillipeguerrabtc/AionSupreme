// client/src/pages/admin/CurationQueuePage.tsx
import React from "react";

export default function CurationQueuePage() {
  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-semibold">Curadoria — Pendências</h1>
      <p className="opacity-70 text-sm">Liste aqui os documentos em <code>curation/pending</code>, com ações: aprovar, editar rótulos, publicar.</p>
      <div className="border p-4 text-sm">TODO: ligar no store de KB (listar, editar, aprovar)</div>
    </div>
  );
}
