# Add-on: Curador + Promover Resposta à KB

## 1) Rotas
- Importe e registre `registerKbPromoteRoutes` em `server/routes.ts`:
  ```ts
  import { registerKbPromoteRoutes } from "./routes/kb_promote";
  export function registerRoutes(app) {
    // ...
    registerKbPromoteRoutes(app);
  }
  ```

## 2) Botão "Promover"
- Use `PromoteToKBButton` ao renderizar a última resposta:
  ```tsx
  <PromoteToKBButton answerText={lastAnswer} defaultNamespaces={["turismo/sintra/guias"]} />
  ```

## 3) Curador
- Carregue `server/seeds/curator.seed.json` junto com seus seeds de agentes.
- Opcional: configurar o Planner para acionar o Curador quando a intenção for "curate/promote".

## 4) Fila de Curadoria
- `client/src/pages/admin/CurationQueuePage.tsx` lista `curation/pending` (adicione no sidebar).
- Ações: aprovar/editar/publicar → emitir `DOC_UPDATED` + `AGENT_NAMESPACES_CHANGED` quando mudar rótulos.
